import React from "react";

export default (props) => (
  <>
    <p className="instructions">
      WASD or Arrow keys to move - Shift, / or up to Rotate
      <br />
      Enter to pause or restart - Z to undo.
      <br />M - Mute music
      <br />
      Also supports gamepads in some browsers.
    </p>
  </>
);
