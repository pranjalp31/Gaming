import React from "react";

export default ({ label, value }) => (
  <div className="scoreboardText">
    {label}: {value}
  </div>
);
